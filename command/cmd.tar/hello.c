#include "type.h"
#include "stdio.h"
#include "unistd.h"

int main(int argc, char * argv[])
{
	printf("hello, world\n");
	return 0;
}
